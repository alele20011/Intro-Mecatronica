

// =====================================================================
//  CARRITO DE FUTBOL ROBOTICO - CONTROL XBOX POR BLUETOOTH (BLE)
//  Placa: ESP32 DevKit V1
//  Driver: TB6612FNG (2 motores)  |  Mecanismo de tiro: servo SG90
// =====================================================================

// ---------------------------------------------------------------------
//  LIBRERIAS
// ---------------------------------------------------------------------
#include <Arduino.h>            // Funciones basicas de Arduino
#include <BLEGamepadClient.h>   // Permite que el ESP32 se conecte al control Xbox por BLE
#include <ESP32Servo.h>         // Control del servo del mecanismo de tiro
#include <BluetoothSerialConnect.h> //permite la conceccion por bluetooth
// ---------------------------------------------------------------------
//  OBJETOS GLOBALES
// ---------------------------------------------------------------------
XboxController controller;      // Representa al control Xbox
Servo brazoServo;               // Representa al servo que patea

// ---------------------------------------------------------------------
//  PINES DEL DRIVER TB6612FNG
//  Motor A = lado IZQUIERDO, Motor B = lado DERECHO
//  AIN1/AIN2 y BIN1/BIN2 deciden el sentido de giro.
//  PWMA y PWMB deciden la velocidad (0 a 255).
//  STBY debe estar en HIGH para que el driver funcione.
// ---------------------------------------------------------------------
const int pinPWMA = 14;
const int pinAIN1 = 27;
const int pinAIN2 = 26;
const int pinBIN1 = 25;
const int pinBIN2 = 33;
const int pinPWMB = 32;
const int pinSTBY = 4;

// ---------------------------------------------------------------------
//  SERVO DE TIRO (como la palanquita de un pinball)
// ---------------------------------------------------------------------
const int pinSERVO   = 13;   // Pin de senal del servo
const int POS_REPOSO = 0;    // Angulo con el brazo retraido
const int POS_GOLPE  = 90;   // Angulo con el brazo extendido (golpe)

// ---------------------------------------------------------------------
//  LED INTEGRADO DEL ESP32
//  Parpadea mientras busca el control y queda fijo al conectarse.
// ---------------------------------------------------------------------
const int pinLED = 2;

// =====================================================================

// =====================================================================

// Pon false si el ESP32 se reinicia al encender, para descartar al servo
const bool USAR_SERVO = true;

// Inversiones: si algo se mueve al reves, cambia true/false
const bool INVERTIR_Y       = false;  // true si palanca arriba hace ir hacia atras
const bool INVERTIR_X       = false;  // true si el giro sale al lado contrario
const bool INVERTIR_MOTOR_A = false;  // true si el motor izquierdo gira al reves
const bool INVERTIR_MOTOR_B = false;  // true si el motor derecho gira al reves

// Palanca: zona muerta. Valores menores a 0.12 se ignoran para evitar
// que el carrito se mueva solo por el ruido de la palanca.
const float ZONA_MUERTA = 0.12;

// PWM minimo con el que los motores si logran moverse (menos de esto solo zumban)
const int PWM_MINIMO = 60;

// Los 3 niveles de velocidad (R2). Se cambian con RB (subir) y LB (bajar).
// Se dejan por debajo de 255 para que el TURBO sea realmente mas rapido.
const int NIVELES[3] = {130, 180, 225};
int nivel = 1;                        // Nivel inicial: 1 = media (indices 0, 1 y 2)

// TURBO: se activa mientras mantienes el gatillo izquierdo (LT)
const int PWM_TURBO = 255;            // Maxima potencia posible

// Aceleracion: cuanto puede subir el PWM en cada ciclo de 10 ms.
// Un valor chico suaviza el arranque y protege la bateria; uno grande responde mas rapido.
const int PASO_ACEL       = 25;       // Modo normal
const int PASO_ACEL_TURBO = 70;       // Modo turbo (arranca casi de golpe)

// Cada cuantos milisegundos se recalculan los motores
const unsigned long PERIODO_CONTROL = 10;

// Mecanismo de tiro: tiempos en milisegundos
const unsigned long TIEMPO_GOLPE   = 120;  // Cuanto tiempo queda extendido el brazo
const unsigned long TIEMPO_RECARGA = 300;  // Espera minima antes del siguiente tiro

// Failsafe (R4): SIEMPRE se detiene si el control se desconecta.
// Opcional: tambien detener si la palanca no cambia durante TIEMPO_FAILSAFE.
// Dejar en false si el control no manda datos cuando la palanca esta quieta.
const bool USAR_WATCHDOG = false;
const unsigned long TIEMPO_FAILSAFE = 1000;

// true imprime datos en el Monitor Serie para diagnosticar
const bool DEBUG = true;

// =====================================================================
//  CONFIGURACION DEL PWM DE LOS MOTORES
// =====================================================================
const int PWM_FREQ = 20000;   // 20 kHz: no se escucha como zumbido
const int PWM_RES  = 8;       // 8 bits: valores de 0 a 255

// =====================================================================
//  VARIABLES DE ESTADO (guardan lo que esta pasando en el carrito)
// =====================================================================

// Velocidad actual de cada motor (positivo = adelante, negativo = atras)
int actualA = 0;
int actualB = 0;

// Maquina de estados del tiro, para patear sin bloquear el programa con delay()
enum EstadoTiro { TIRO_LIBRE, TIRO_EXTENDIDO, TIRO_RECARGA };
EstadoTiro estadoTiro = TIRO_LIBRE;
unsigned long inicioTiro = 0;

// Estado anterior de botones, para detectar el MOMENTO en que se presionan
bool prevLB = false, prevRB = false, prevTiro = false, prevTurbo = false;

// Ultimos valores de la palanca, para detectar si hubo cambios (reportes)
float ultX = 0, ultY = 0;
unsigned long ultimoCambio  = 0;  // Cuando cambio la palanca por ultima vez
unsigned long ultimoControl = 0;  // Cuando se calcularon los motores por ultima vez
unsigned long ultimoDebug   = 0;  // Cuando se imprimio por ultima vez
unsigned long reportes      = 0;  // Contador de cambios de la palanca

// =====================================================================
//  MOTORES
// =====================================================================

// Pone un motor en el sentido que indique "valor":
//   positivo = adelante, negativo = atras, cero = freno corto
void direccionMotor(int in1, int in2, int valor) {
  if (valor > 0) {                       // Adelante
    digitalWrite(in1, HIGH);
    digitalWrite(in2, LOW);
  } else if (valor < 0) {                // Atras
    digitalWrite(in1, LOW);
    digitalWrite(in2, HIGH);
  } else {                               // Freno corto: ambas entradas en HIGH
    digitalWrite(in1, HIGH);
    digitalWrite(in2, HIGH);
  }
}

// Envia la velocidad y direccion final a los dos motores
void escribirMotores(int a, int b) {
  if (INVERTIR_MOTOR_A) a = -a;          // Aplica las inversiones de los ajustes
  if (INVERTIR_MOTOR_B) b = -b;
  direccionMotor(pinAIN1, pinAIN2, a);   // Sentido del motor izquierdo
  direccionMotor(pinBIN1, pinBIN2, b);   // Sentido del motor derecho
  ledcWrite(pinPWMA, abs(a));            // Velocidad del motor izquierdo
  ledcWrite(pinPWMB, abs(b));            // Velocidad del motor derecho
}

// Detiene todo inmediatamente
void detenerTodo() {
  actualA = 0;
  actualB = 0;
  escribirMotores(0, 0);
}

// Suaviza la aceleracion: sube la velocidad poco a poco (maximo "paso" por ciclo).
// Frenar o bajar la velocidad si es inmediato.
// Si cambia el sentido (adelante a atras) pasa primero por cero.
int rampa(int actual, int objetivo, int paso) {
  if ((actual > 0 && objetivo < 0) || (actual < 0 && objetivo > 0)) actual = 0;
  if (abs(objetivo) <= abs(actual)) return objetivo;           // Frenar o bajar: directo
  if (objetivo > 0) return min(actual + paso, objetivo);       // Subir hacia adelante
  return max(actual - paso, objetivo);                         // Subir hacia atras
}

// Convierte una intensidad (-1 a 1) en un valor PWM (60 hasta "tope").
// "tope" es el nivel elegido, o el turbo si esta activado.
int valorPWM(float v, int tope) {
  float a = fabsf(v);                              // Intensidad sin signo
  if (a < 0.03) return 0;                          // Muy pequena: no mover
  int pwm = PWM_MINIMO + (int)(a * (tope - PWM_MINIMO));  // Escala entre minimo y tope
  return v > 0 ? pwm : -pwm;                       // Recupera el signo (adelante o atras)
}

// Convierte la posicion de la palanca (x, y) en velocidades para los 2 motores.
// Mezcla tipo "arcade":
//   y = avance (arriba o abajo)   x = giro (izquierda o derecha)
//   - Solo adelante o atras: las dos ruedas iguales
//   - Adelante mas un lado: curva (la rueda interior va mas lenta)
//   - Solo a un lado: el carrito gira sobre su propio eje
void calcularObjetivo(float x, float y, int tope, int &objA, int &objB) {
  float mag = sqrtf(x * x + y * y);                // Que tan lejos esta la palanca del centro
  if (mag < ZONA_MUERTA) {                         // Dentro de la zona muerta: alto
    objA = 0;
    objB = 0;
    return;
  }
  if (mag > 1.0f) {                                // Limita a 1 (en las diagonales puede pasar)
    x /= mag;
    y /= mag;
    mag = 1.0f;
  }
  float escala = (mag - ZONA_MUERTA) / (1.0f - ZONA_MUERTA);  // Reescala: 0 al salir de la zona muerta
  x = x / mag * escala;
  y = y / mag * escala;

  float izq = y + x;                               // Motor A = izquierdo
  float der = y - x;                               // Motor B = derecho
  float mx  = fmaxf(fabsf(izq), fabsf(der));
  if (mx > 1.0f) {                                 // Si una rueda pasa de 1, se reducen ambas proporcionalmente
    izq /= mx;
    der /= mx;
  }

  objA = valorPWM(izq, tope);                      // Velocidad objetivo del motor izquierdo
  objB = valorPWM(der, tope);                      // Velocidad objetivo del motor derecho
}

// =====================================================================
//  MECANISMO DE TIRO (SERVO)
// =====================================================================

// Inicia un tiro: extiende el brazo. Solo si esta libre (evita tiros repetidos).
void iniciarTiro() {
  if (!USAR_SERVO || estadoTiro != TIRO_LIBRE) return;
  brazoServo.write(POS_GOLPE);
  inicioTiro = millis();
  estadoTiro = TIRO_EXTENDIDO;
}

// Se llama en cada vuelta del programa: regresa el brazo y controla la recarga
void actualizarTiro(unsigned long ahora) {
  switch (estadoTiro) {
    case TIRO_EXTENDIDO:                                   // Brazo afuera
      if (ahora - inicioTiro >= TIEMPO_GOLPE) {
        brazoServo.write(POS_REPOSO);                      // Regresa el brazo
        estadoTiro = TIRO_RECARGA;
      }
      break;
    case TIRO_RECARGA:                                     // Esperando para permitir otro tiro
      if (ahora - inicioTiro >= TIEMPO_GOLPE + TIEMPO_RECARGA) {
        estadoTiro = TIRO_LIBRE;
      }
      break;
    default:
      break;
  }
}

// =====================================================================
//  SETUP: se ejecuta una sola vez al encender
// =====================================================================
void setup() {
  Serial.begin(115200);              // Comunicacion con el Monitor Serie
  delay(500);

  Serial.println();
  Serial.println("========================================");
  Serial.println("   CARRITO FUTBOL - CONTROL XBOX");
  Serial.println("========================================");
  // Motivo del ultimo reinicio: 1 normal, 3 software, 4 error, 9 falta de voltaje
  Serial.printf("Motivo de reinicio: %d\n", (int)esp_reset_reason());

  // 1) Servo primero (se configura antes que el PWM de los motores)
  if (USAR_SERVO) {
    brazoServo.attach(pinSERVO);
    brazoServo.write(POS_REPOSO);    // Empieza con el brazo retraido
  }

  // 2) Pines del driver como salidas
  pinMode(pinAIN1, OUTPUT);
  pinMode(pinAIN2, OUTPUT);
  pinMode(pinBIN1, OUTPUT);
  pinMode(pinBIN2, OUTPUT);
  pinMode(pinSTBY, OUTPUT);
  digitalWrite(pinSTBY, HIGH);       // Activa el driver
  pinMode(pinLED, OUTPUT);

  // 3) PWM de los motores
  ledcAttach(pinPWMA, PWM_FREQ, PWM_RES);
  ledcAttach(pinPWMB, PWM_FREQ, PWM_RES);

  detenerTodo();                     // Arranca con los motores detenidos

  // 4) Inicia la busqueda del control Xbox
  controller.begin();
  Serial.println("Esperando control Xbox...");
  ultimoCambio = millis();
}

// =====================================================================
//  LOOP: se repite todo el tiempo
// =====================================================================
void loop() {
  unsigned long ahora = millis();    // Tiempo actual en milisegundos
  actualizarTiro(ahora);             // Mantiene al dia la secuencia del servo

  // ---- CONTROL DESCONECTADO: detener todo (R4) ----
  if (!controller.isConnected()) {
    detenerTodo();                                          // Motores en alto
    prevLB = prevRB = prevTiro = prevTurbo = false;         // Borra botones recordados
    ultimoCambio = ahora;
    digitalWrite(pinLED, (ahora / 250) % 2);                // LED parpadea (buscando)

    static unsigned long ultimoMensaje = 0;                 // Mensaje cada 1 s
    if (ahora - ultimoMensaje > 1000) {
      Serial.println("Control no conectado...");
      ultimoMensaje = ahora;
    }
    delay(10);
    return;                                                 // No sigue con el resto
  }

  digitalWrite(pinLED, HIGH);                               // LED fijo = conectado

  // ---- LEE EL CONTROL ----
  XboxControlsState s;               // Estado de todos los botones y palancas
  controller.read(&s);

  // ---- NIVELES DE VELOCIDAD: RB sube, LB baja ----
  // Solo reacciona en el momento de presionar (no mientras se mantiene)
  bool lb = s.leftBumper, rb = s.rightBumper;
  if (rb && !prevRB && nivel < 2) { nivel++; Serial.printf("Nivel %d\n", nivel + 1); }
  if (lb && !prevLB && nivel > 0) { nivel--; Serial.printf("Nivel %d\n", nivel + 1); }
  prevLB = lb;
  prevRB = rb;

  // ---- TURBO: se mantiene mientras el gatillo izquierdo este presionado ----
  bool turbo = (s.leftTrigger > 0.5);
  if (turbo != prevTurbo) {
    Serial.println(turbo ? "TURBO ACTIVADO" : "Turbo desactivado");
    prevTurbo = turbo;
  }

  // ---- TIRO: boton A o gatillo derecho (solo al presionar) ----
  bool pedirTiro = s.buttonA || (s.rightTrigger > 0.5);
  if (pedirTiro && !prevTiro) iniciarTiro();
  prevTiro = pedirTiro;

  // ---- CONTEO DE CAMBIOS EN LA PALANCA (para el watchdog y el diagnostico) ----
  if (s.leftStickX != ultX || s.leftStickY != ultY) {
    ultX = s.leftStickX;
    ultY = s.leftStickY;
    ultimoCambio = ahora;
    reportes++;
  }

  // ---- CONTROL DE MOTORES (cada 10 ms) ----
  if (ahora - ultimoControl >= PERIODO_CONTROL) {
    ultimoControl = ahora;

    // Lee la palanca izquierda y aplica las inversiones de los ajustes
    float x = s.leftStickX;
    float y = s.leftStickY;
    if (INVERTIR_Y) y = -y;
    if (INVERTIR_X) x = -x;

    // Elige la velocidad maxima: turbo o el nivel actual
    int tope = turbo ? PWM_TURBO : NIVELES[nivel];

    // Calcula la velocidad que debe tener cada motor
    int objA, objB;
    calcularObjetivo(x, y, tope, objA, objB);

    // Boton B = alto de emergencia
    if (s.buttonB) {
      objA = 0;
      objB = 0;
    }

    // Failsafe opcional: si la palanca no cambia por mucho tiempo, detener
    if (USAR_WATCHDOG && (objA != 0 || objB != 0) && (ahora - ultimoCambio >= TIEMPO_FAILSAFE)) {
      objA = 0;
      objB = 0;
    }

    // Acelera de forma gradual hacia la velocidad objetivo
    int paso = turbo ? PASO_ACEL_TURBO : PASO_ACEL;
    actualA = rampa(actualA, objA, paso);
    actualB = rampa(actualB, objB, paso);
    escribirMotores(actualA, actualB);

    // ---- DIAGNOSTICO EN EL MONITOR SERIE (4 veces por segundo) ----
    if (DEBUG && ahora - ultimoDebug >= 250) {
      Serial.printf("X:%6.2f Y:%6.2f | A:%4d B:%4d | nivel:%d turbo:%d | rep/s:%lu\n",
                    x, y, actualA, actualB, nivel + 1, turbo, reportes * 4);
      reportes = 0;
      ultimoDebug = ahora;
    }
  }
}